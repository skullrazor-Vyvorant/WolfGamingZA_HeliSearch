WolfGamingZA HeliSearch

Original mod: Helicrash Search [Updated] (RELIFE) by VirusomanVS
Original Workshop: https://steamcommunity.com/sharedfiles/filedetails/?id=3121468488

Helicopter wrecks derived from CrashBase can be searched once. Search takes 10 seconds. The original search rewards and defaults are retained.

Configuration: server profiles/WolfGamingZA_HeliSearch/HeliSearch.json (created on first startup).

IMPORTANT: This PBO has been repacked but NOT signed. Sign it using your own DayZ private key and install the matching .bikey on the server. The original .bisign is not valid for this modified PBO. Test on a staging server before deployment.

Keep the original Workshop link when publishing this repack.

See UPDATE_NOTES.md for localization fixes, configuration audit, build validation,
and required staging tests. Update existing Workshop item 3826826172 only.
