modded class CrashBase
{
    bool CanCheckWreck = false;

    void Wreck_Checked()
    {
        CanCheckWreck = true;
    }

    bool CanLootWreck()
    {
        return CanCheckWreck;
    }
}