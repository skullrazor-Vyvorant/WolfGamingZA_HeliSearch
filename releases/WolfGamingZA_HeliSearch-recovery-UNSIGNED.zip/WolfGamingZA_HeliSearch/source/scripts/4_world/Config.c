static ref RLFHeliConfig g_RLFHeliConfig;
static ref RLFHeliConfig GetRLFHeliConfig()
{
    if(!g_RLFHeliConfig) 
	{
		g_RLFHeliConfig = new RLFHeliConfig();
		g_RLFHeliConfig.LoadCFG();
	}
    return g_RLFHeliConfig;
}

class RLFHeliConfig
{
    const static string cfgPath = "$profile:WolfGamingZA/HeliSearch.json";
	const static string dirPath = "$profile:WolfGamingZA";
	
	float HeliChance = 0.8;
	int countOfItems = 5;
	float ItemHealthMin = 0.8;
	float ItemHealthMax = 0.9;
	
	ref TStringArray HeliItems = 
	{
		"AmmoBox_00buck_10rnd",
		"AmmoBox_12gaRubberSlug_10Rnd",
		"AmmoBox_12gaSlug_10Rnd",
		"AmmoBox_22_50Rnd",
		"AmmoBox_308WinTracer_20Rnd",
		"AmmoBox_308Win_20Rnd",
		"AmmoBox_357_20Rnd",
		"AmmoBox_380_35rnd",
		"AmmoBox_545x39Tracer_20Rnd",
		"AmmoBox_545x39_20Rnd",
		"AmmoBox_556x45Tracer_20Rnd",
		"AmmoBox_556x45_20Rnd",
		"AmmoBox_762x39Tracer_20Rnd",
	};
    
    void LoadCFG()
    {
        if (FileExist(cfgPath))
		{
			JsonFileLoader<RLFHeliConfig>.JsonLoadFile(cfgPath, this);
		}
        else
		{
			CreateConfig();
		}
    }
	
    void SaveCFG()
    {
        JsonFileLoader<RLFHeliConfig>.JsonSaveFile( cfgPath, this );
    }

    void CreateConfig()
    {
        if (!FileExist(dirPath))
        {
            Print("[WolfGamingZA HeliSearch] '" + dirPath + "' does not exist, creating...");
            MakeDirectory(dirPath);
        }
        SaveCFG();
	}
}

