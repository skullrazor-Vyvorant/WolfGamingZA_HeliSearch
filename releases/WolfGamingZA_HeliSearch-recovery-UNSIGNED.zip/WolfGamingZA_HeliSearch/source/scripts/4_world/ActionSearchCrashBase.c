class  ActionSearchCrashBaseCB : ActionContinuousBaseCB
{
	//Time limit for the search
	private const float ACTION_TIME = 10.0;
  
  	override void CreateActionComponent()
  	{
  		m_ActionData.m_ActionComponent = new CAContinuousTime(ACTION_TIME);
  	}
};

class  ActionSearchCrashBase: ActionContinuousBase
{	

	void  ActionSearchCrashBase()
	{
		m_CallbackClass =  ActionSearchCrashBaseCB;

		//Interaction setting
		m_CommandUID = DayZPlayerConstants.CMD_ACTIONFB_INTERACT;
		m_FullBody = true;
		m_StanceMask = DayZPlayerConstants.STANCEMASK_ERECT;
		m_SpecialtyWeight = UASoftSkillsWeight.ROUGH_HIGH;
	}

	override void CreateConditionComponents()
	{
		//Interaction contitions
		m_ConditionItem = new CCINone;
		m_ConditionTarget = new CCTCursor(UAMaxDistances.DEFAULT);
	}

	override typename GetInputType()
	{
		return ContinuousInteractActionInput;
	}

	override bool ActionCondition( PlayerBase player, ActionTarget target, ItemBase item )
	{
		Object targetObject = target.GetObject();
		CrashBase wrekcCrash = CrashBase.Cast(targetObject);
		if ( wrekcCrash)
		{
			return true;
		}
		return false;
	}

	override string GetText()
	{
		return "Search Helicopter";
	}

	override void OnFinishProgressServer( ActionData action_data )
	{
		Object targetObject1 = action_data.m_Target.GetObject();
		CrashBase crashWreck = CrashBase.Cast( targetObject1 );
		if(!GetRLFHeliConfig()) return;

		if ( crashWreck)
		{
			if (!crashWreck.CanLootWreck() )
			{
				int loot_success = 0;
				//In
				if( GetRLFHeliConfig().HeliChance >= Math.RandomFloat01())
				{
					int countOfItems =  GetRLFHeliConfig().countOfItems;
					ItemBase LootHeli;
					for(int j = 0; j < countOfItems; j++)
					{
						Class.CastTo(LootHeli,  GetGame().CreateObjectEx(GetRLFHeliConfig().HeliItems.GetRandomElement(), action_data.m_Player.GetPosition(), ECE_PLACE_ON_SURFACE) );
						LootHeli.SetHealth01("", "", Math.RandomFloatInclusive(GetRLFHeliConfig().ItemHealthMin, GetRLFHeliConfig().ItemHealthMax));
					}
					loot_success = 1;
				}
				else
				{
					NotificationSystem.SendNotificationToPlayerIdentityExtended(action_data.m_Player.GetIdentity() , 5, "Helicopter Search", "Nothing useful found.", "set:ccgui_enforce image:MapUserMarker" );
				}

				if (loot_success == 1)
				{
					NotificationSystem.SendNotificationToPlayerIdentityExtended(action_data.m_Player.GetIdentity() , 5, "Helicopter Search", "Supplies Found", "set:ccgui_enforce image:MapUserMarker" );
				}			
			} 
			else 
			{
				if(action_data.m_Player.GetIdentity())
				{
					NotificationSystem.SendNotificationToPlayerIdentityExtended(action_data.m_Player.GetIdentity() , 5, "Helicopter Search", "Already Searched", "set:ccgui_enforce image:MapUserMarker" );
				}
			}
			crashWreck.Wreck_Checked();
		}
	}

}