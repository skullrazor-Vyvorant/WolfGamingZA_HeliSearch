class CfgPatches
{
	class WolfGamingZA_HeliSearch
	{
		units[] = {
			
		};
		weapons[] = {};
		requiredVersion = 0.1;
		requiredAddons[] =
			{
			};
	};
};

class CfgMods
{
	class WolfGamingZA_HeliSearch
	{
		dir = "WolfGamingZA_HeliSearch";
		picture = "";
		action = "";
		hideName = 1;
		hidePicture = 1;
		name = "WolfGamingZA HeliSearch";
		credits = "Original mod: RELIFE / VirusomanVS (Workshop 3121468488)";
		author = "WolfGamingZA";
		version = "1";
		extra = 0;
		type = "mod";
		dependencies[] =
			{
				"Game",
				"World",
				"Mission"};
		class defs
		{
			class gameScriptModule
			{
				value = "";
				files[] =
					{
						"WolfGamingZA_HeliSearch/scripts/3_Game"};
			};
			class worldScriptModule
			{
				value = "";
				files[] =
					{
						"WolfGamingZA_HeliSearch/scripts/4_World"};
			};
			class missionScriptModule
			{
				value = "";
				files[] =
					{
						"WolfGamingZA_HeliSearch/scripts/5_Mission"};
			};
		};
	};
};

class CfgSoundShaders
{
	class points_search_shader_Base
	{
		range=80;
		volume=1;
		distance=5;
	};
	class fridge_search_shader_start: points_search_shader_Base
	{
		volume=1.9;
		samples[]=
		{
			
			{
				"WolfGamingZA_HeliSearch\sounds\fridge_start",
				1
			}
		};
	};
	class fridge_search_shader_end: points_search_shader_Base
	{
		samples[]=
		{
			
			{
				"WolfGamingZA_HeliSearch\sounds\fridge_close",
				1
			}
		};
	};
};
class CfgSoundSets
{
	class points_search_Soundset_base
	{
		distance=5;
		loop=0;
		spatial=1;
		frequencyRandomizer=0;
		volumeRandomizer=0;
		volumeFactor=1;
	};
	class fridge_search_soundset_start: points_search_Soundset_base
	{
		loop=1;
		soundShaders[]=
		{
			"fridge_search_shader_start"
		};
	};
	class fridge_search_soundset_end: points_search_Soundset_base
	{
		soundShaders[]=
		{
			"fridge_search_shader_end"
		};
	};
};
