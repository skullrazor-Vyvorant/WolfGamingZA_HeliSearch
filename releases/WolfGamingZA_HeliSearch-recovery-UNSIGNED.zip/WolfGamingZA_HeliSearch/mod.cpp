name = "WolfGamingZA HeliSearch";
author = "WolfGamingZA (based on RELIFE / VirusomanVS)";
version = "1.0";
