#!/usr/bin/env python3
"""Patch the supplied uncompressed DayZ PBO without changing its compiled config.
Usage: python3 tools/rebuild.py ORIGINAL.pbo OUTPUT.pbo
This is a targeted repack, not an Enforce Script compiler or BI signing tool.
"""
import csv
import hashlib
import io
from pathlib import Path
import re
import struct
import sys
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]

def read_pbo(path):
    data = Path(path).read_bytes()
    assert data[-21:-20] == b'\0'
    assert hashlib.sha1(data[:-21]).digest() == data[-20:], 'Invalid PBO checksum'
    pos = 0
    def string():
        nonlocal pos
        end = data.index(b'\0', pos)
        result = data[pos:end]
        pos = end + 1
        return result
    records = []
    while True:
        name = string()
        fields = struct.unpack_from('<5I', data, pos)
        pos += 20
        if not name and fields[0] == 0x56657273:
            while string():
                string()
            continue
        if not name:
            break
        assert fields[0] == 0, 'Compressed PBOs are not supported'
        records.append((name, fields))
    header = data[:pos]
    entries = {}
    for name, fields in records:
        entries[name.decode()] = (fields, data[pos:pos + fields[4]])
        pos += fields[4]
    assert pos == len(data) - 21
    return header, entries

def main():
    if len(sys.argv) != 3:
        raise SystemExit(__doc__)
    base, out = map(Path, sys.argv[1:])
    header, entries = read_pbo(base)
    original = dict(entries)
    # Retain original compiled config, sound assets, paths and prefix verbatim.
    for name, (fields, payload) in list(entries.items()):
        if name.startswith('scripts\\'):
            source = ROOT / 'source' / Path(name.replace('\\', '/'))
            assert source.is_file(), source
            payload = source.read_bytes()
            entries[name] = ((0, 0, 0, fields[3], len(payload)), payload)
    for name in ('stringtable.csv', 'stringtable.xml'):
        payload = (ROOT / 'source' / name).read_bytes()
        entries[name] = ((0, 0, 0, 0, len(payload)), payload)
    xml = {k.attrib['ID']: k.findtext('English') for k in ET.fromstring(entries['stringtable.xml'][1]).iter('Key')}
    rows = list(csv.reader(io.StringIO(entries['stringtable.csv'][1].decode())))
    assert rows[0] == ['Language', 'original', 'english']
    assert {r[0]: r[2] for r in rows[1:]} == xml
    refs = set()
    for p in (ROOT / 'source/scripts').rglob('*.c'):
        refs.update(re.findall(r'#(STR_RLF_\w+)', p.read_text()))
    assert refs == set(xml), (refs, set(xml))
    assert all(r[1] == r[2] and r[1].isascii() for r in rows[1:])
    # Preserve the extension/property header including the virtual prefix.
    ext_end = header.index(b'config.bin\0')
    result = bytearray(header[:ext_end])
    for name, (fields, payload) in entries.items():
        result += name.encode() + b'\0' + struct.pack('<5I', *fields)
    result += b'\0' + bytes(20)
    for fields, payload in entries.values():
        result += payload
    result += b'\0' + hashlib.sha1(result).digest()
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_bytes(result)
    _, verified = read_pbo(out)
    assert verified == entries
    changed = [name for name in entries if entries[name][1] != original.get(name, (None, None))[1]]
    assert set(changed) == {'scripts\\4_world\\Config.c', 'stringtable.csv', 'stringtable.xml'}
    print('Verified:', len(entries), 'PBO entries;', len(refs), 'localized keys')
    print('Changed payloads:', ', '.join(changed))
    print('SHA256:', hashlib.sha256(result).hexdigest())
    print('UNSIGNED: generate a new .bisign with the existing private key before deployment.')

if __name__ == '__main__':
    main()
